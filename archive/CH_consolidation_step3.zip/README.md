# CHconsolidatechecker_step3
checks phasing of zones 
